<!DOCTYPE html>
<html>
<head>
    <title>UNIWARA</title>
    <link rel="stylesheet" type="text/css" href="beranda.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
</head>
 <style>
    body {
      background-color: #a6a39a;
    }
</style>
<body>

    <div class="container">
	<div class="judul">
	<header>
		<div class="logo">
		<img src="uniwara.jpg">
		<h1  color="#2874A6">Universitas PGRI <br> Wiranegara</h1></font>
	</div><br><br>
    <nav>
        <ul>
            <li><a href="beranda.php">Beranda</a></li>
            <li><a href="tentangSaya.php">Tentang Saya</a></li>
			<li><a href="kontakSaya.php">Kontak Saya</a></li>
            <li><a class="end" href="logout.php">Logout</a></li>
        </ul>
    </nav>

	<div class="content">
		<h1>Selamat Datang !</h1>
		<p>Salam untuk mahasiswa Universitas PGRI Wiranegara Pasuruan. 
		BAAK memberikan informasi terkait Surat Mahasiswa Online, 
		yang salah satunya pembuatan suarat keterangan mahasiswa aktif.</p>
        <p>Berikut Untuk Pembuatan Surat Keterangan Mahasiswa Aktif </p>
        <div class="konten">
            <a href="alfan/index.php"></a>
        <div class="judul">
             <a href="buat/tabel.php"><button>Buat Surat</button></a>
        </div>
        </div>
    </div>
      <footer>
    &copy; 2023 @akurudianttt
</footer>
    </div>
</body>
</html>
