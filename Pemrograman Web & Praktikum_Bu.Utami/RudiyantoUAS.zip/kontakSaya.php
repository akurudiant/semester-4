<!DOCTYPE html>
<html>
<head>
    <title>UNIWARA</title>
    <link rel="stylesheet" type="text/css" href="beranda.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
</head>
<style>
 <style>
    body {
      background-color: #a6a39a;
    }

</style>
<body>
    <div class="container">
    <nav>
        <ul>
            <li><a href="beranda.php">Beranda</a></li>
            <li><a href="tentangSaya.php">Tentang Saya</a></li>
			<li><a href="kontakSaya.php">Kontak Saya</a></li>
            <li><a class="end" href="logout.php">Logout</a></li>
        </ul>
    </nav>

<section class="kontak-saya">
    <h2>Kontak Saya</h2>
    <ul>
        <li><strong>Telepon:</strong> <a href="https://wa.me/6282245297616" target="_blank">wa.+62 822-4529-7616</a></li>
        <li><strong>Email:</strong> <a href="mailto:ahmadrudianto7722@gmail.com">ahmadrudianto7722@gmail.com</a></li>
		<li><strong>Alamat:</strong> Dsun. Parasan, Ds.Sanganom, Kec.Nguling,Kab.Pasuruan, Jawa Timur-Indonesia</li>
    </ul>
</section>

	
 <footer>
    &copy; 2023 @akurudianttt
</footer>
    </div>
</body>
</html>
