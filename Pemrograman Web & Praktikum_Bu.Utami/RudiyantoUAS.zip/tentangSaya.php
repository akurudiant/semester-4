<!DOCTYPE html>
<html>
<head>
    <title>UNIWARA</title>
    <link rel="stylesheet" type="text/css" href="beranda.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
</head>
<style>
 <style>
    body {
      background-color: #a6a39a;
    }
</style>
<body>
    <div class="container">
    <nav>
        <ul>
            <li><a href="beranda.php">Beranda</a></li>
            <li><a href="tentangSaya.php">Tentang Saya</a></li>
			<li><a href="kontakSaya.php">Kontak Saya</a></li>
            <li><a class="end" href="logout.php">Logout</a></li>
        </ul>
    </nav>
	<section class="tentang-saya">
    <h2>Tentang Saya</h2>
    <ul>
        <li><strong>NAMA	:</strong>Ahmad Rudiyanto</li>
        <li><strong>NIM		:</strong> 21157201114</li>
        <li><strong>Prodi	:</strong>Ilmu Komputer</li>
        <li><strong>Angkatan:</strong> 2021</li>
    </ul>
</section>
<footer>
    &copy; 2023 @akurudianttt
</footer>
    </div>
</body>
</html>
